# Maze Game  
Welcome to the interactive maze game! Many people play at once, Only the latest move is applied.

**Player position:** (1, 4)  
![Maze](https://github-maze-game.vercel.app/images/pos_1_4.png?t=1761102482920)

Use these to move:  
[⬆️ Move up](https://github-maze-game.vercel.app/move/1_4_w)  
[⬇️ Move down](https://github-maze-game.vercel.app/move/1_4_s)  
[⬅️ Move left](https://github-maze-game.vercel.app/move/1_4_a)  
[➡️ Move right](https://github-maze-game.vercel.app/move/1_4_d)
